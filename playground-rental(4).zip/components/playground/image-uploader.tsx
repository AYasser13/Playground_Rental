"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Trash2, Upload, ImageIcon } from "lucide-react"
import Image from "next/image"
import { useToast } from "@/components/ui/use-toast"

interface ImageUploaderProps {
  images: string[]
  setImages: (images: string[]) => void
  disabled?: boolean
}

export function ImageUploader({ images, setImages, disabled = false }: ImageUploaderProps) {
  const [isUploading, setIsUploading] = useState(false)
  const { toast } = useToast()

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return

    setIsUploading(true)

    const newImages: string[] = []
    const filePromises = Array.from(e.target.files).map((file) => {
      return new Promise<void>((resolve, reject) => {
        // Check file size (limit to 5MB)
        if (file.size > 5 * 1024 * 1024) {
          toast({
            title: "File too large",
            description: `${file.name} exceeds the 5MB limit.`,
            variant: "destructive",
          })
          resolve()
          return
        }

        const reader = new FileReader()
        reader.onload = (event) => {
          if (event.target?.result) {
            newImages.push(event.target.result as string)
          }
          resolve()
        }
        reader.onerror = () => {
          toast({
            title: "Upload failed",
            description: `Failed to read ${file.name}.`,
            variant: "destructive",
          })
          resolve()
        }
        reader.readAsDataURL(file)
      })
    })

    Promise.all(filePromises)
      .then(() => {
        if (newImages.length > 0) {
          setImages([...images, ...newImages])
        }
      })
      .catch((error) => {
        console.error("Error uploading images:", error)
        toast({
          title: "Upload failed",
          description: "There was an error uploading your images.",
          variant: "destructive",
        })
      })
      .finally(() => {
        setIsUploading(false)
        // Clear the input value to allow uploading the same file again
        if (e.target) {
          e.target.value = ""
        }
      })
  }

  const removeImage = (index: number) => {
    const updatedImages = [...images]
    updatedImages.splice(index, 1)
    setImages(updatedImages)
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
        {images.map((image, index) => (
          <div key={index} className="relative aspect-video rounded-md border bg-muted">
            <Image
              src={image || "/placeholder.svg"}
              alt={`Playground image ${index + 1}`}
              fill
              className="rounded-md object-cover"
            />
            <Button
              type="button"
              variant="destructive"
              size="icon"
              className="absolute right-1 top-1 h-6 w-6"
              onClick={() => removeImage(index)}
              disabled={disabled}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        ))}
        {images.length === 0 && (
          <div className="flex aspect-video items-center justify-center rounded-md border bg-muted">
            <div className="flex flex-col items-center text-muted-foreground">
              <ImageIcon className="mb-2 h-8 w-8" />
              <span className="text-xs">No images</span>
            </div>
          </div>
        )}
      </div>

      <div className="flex items-center gap-4">
        <Input
          type="file"
          accept="image/*"
          multiple
          onChange={handleImageUpload}
          disabled={disabled || isUploading}
          className="hidden"
          id="image-upload"
        />
        <Button
          type="button"
          variant="outline"
          onClick={() => document.getElementById("image-upload")?.click()}
          disabled={disabled || isUploading}
          className="w-full"
        >
          <Upload className="mr-2 h-4 w-4" />
          {isUploading ? "Uploading..." : "Upload Images"}
        </Button>
      </div>
      <p className="text-xs text-muted-foreground">
        Upload images of your playground. You can upload multiple images at once. Maximum file size: 5MB.
      </p>
    </div>
  )
}
